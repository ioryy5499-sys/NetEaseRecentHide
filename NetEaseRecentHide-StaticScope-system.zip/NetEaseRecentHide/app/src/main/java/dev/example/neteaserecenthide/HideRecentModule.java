package dev.example.neteaserecenthide;

import android.content.ComponentName;
import android.content.Intent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Method;

/**
 * Hooks only system_server's Recents visibility decision.
 * It does not hook or modify NetEase Cloud Music's player/service/media session.
 */
public final class HideRecentModule implements IXposedHookLoadPackage {
    private static final String TAG = "[NetEaseRecentHide]";
    private static final String TARGET_PACKAGE = "com.netease.cloudmusic";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"android".equals(lpparam.packageName)) {
            return;
        }

        try {
            Class<?> recentTasksClass = XposedHelpers.findClass(
                    "com.android.server.wm.RecentTasks", lpparam.classLoader);

            int hooked = 0;
            for (Method method : recentTasksClass.getDeclaredMethods()) {
                if (!"isVisibleRecentTask".equals(method.getName())) {
                    continue;
                }
                if (method.getReturnType() != boolean.class &&
                    method.getReturnType() != Boolean.class) {
                    continue;
                }

                XposedBridge.hookMethod(method, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (param.args == null || param.args.length == 0 || param.args[0] == null) {
                            return;
                        }

                        Object task = param.args[0];
                        if (isTargetTask(task)) {
                            param.setResult(false);
                            XposedBridge.log(TAG + " hid a NetEase Cloud Music task from Recents");
                        }
                    }
                });
                hooked++;
            }

            if (hooked == 0) {
                XposedBridge.log(TAG + " WARNING: no RecentTasks.isVisibleRecentTask method found. " +
                        "This HyperOS build may use a different implementation.");
            } else {
                XposedBridge.log(TAG + " hooked " + hooked + " RecentTasks visibility method(s)");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + " failed to install hook: " + t);
        }
    }

    private static boolean isTargetTask(Object task) {
        // Prefer the task's base intent, which is how AOSP-based Recents usually identifies it.
        try {
            Object value = XposedHelpers.callMethod(task, "getBaseIntent");
            if (value instanceof Intent) {
                Intent intent = (Intent) value;
                ComponentName component = intent.getComponent();
                if (component != null &&
                        TARGET_PACKAGE.equals(component.getPackageName())) {
                    return true;
                }
                // Fallback for intents whose package is set without a component.
                if (TARGET_PACKAGE.equals(intent.getPackage())) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
            // Try the task's real activity below.
        }

        // OEM builds may expose the real activity separately.
        try {
            Object value = XposedHelpers.callMethod(task, "getRealActivity");
            if (value instanceof ComponentName) {
                return TARGET_PACKAGE.equals(((ComponentName) value).getPackageName());
            }
        } catch (Throwable ignored) {
            // No compatible method on this ROM.
        }

        return false;
    }
}
